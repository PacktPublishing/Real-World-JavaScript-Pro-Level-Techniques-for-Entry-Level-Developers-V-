var map;
var google_api_key = "AIzaSyBDW4T-usvr99-_uELulYaDf4Cg6K1heu0"

//google maps documentation: https://developers.google.com/maps/documentation/javascript/earthquakes#circle_size
function initMap() {
	map = new google.maps.Map(document.getElementById('map'), {
		center: {lat: 2.8, lng: -187},
		zoom: 1.5
	});
	
	//create a set of markers
	var nyc = {lat: 40.798, lng: -73.964};
	var mumbai = {lat: 19.082, lng: 72.74};
	var paris = {lat: 48.8589, lng: 2.2768};
	var cape_town = {lat: -33.913, lng: 18.904};
	var marker_nyc = new google.maps.Marker({position: nyc, map: map});
	var marker_mumbai = new google.maps.Marker({position: mumbai, map: map});
	var marker_paris = new google.maps.Marker({position: paris, map: map});
	var marker_cape_town = new google.maps.Marker({position: cape_town, map: map});
}

function bookSearch(title) {
	$.ajax({
		url: "https://www.googleapis.com/books/v1/volumes?q="+title+"&download=epub&langRestrict=English&key="+google_api_key
	}).done(function(resp) {

		//go through the first 10 items in the result and output the basic info
		for (item in resp.items) {
			var book = resp.items[item];
			var book_string = "";
			book_string += "<h3>" + book['volumeInfo']['title'] + "</h3>";
			book_string += "<h4>" + book['volumeInfo']['authors'][0] + "</h4>";
			book_string += "<p>" + book['volumeInfo']['description'] + "</p>";
			$("#book_results").append(book_string);
			
			//check to see if we've already displayed 10 items, if so, break out of the loop.
			if (item >= 9) break;
		}
	});
}

$(document).ready(function() {
	$("#search_button").click(function() {
		if ($("#search_text").val() != "") {
			bookSearch($("#search_text").val());
		}
	});
});