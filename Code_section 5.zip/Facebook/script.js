//Facebook's default initialization for reference
/*
window.fbAsyncInit = function() {
	FB.init({
		appId            : '2721267708098832',
		autoLogAppEvents : true,
		xfbml            : true,
		version          : 'v3.2'
	});
};

(function(d, s, id){
	var js, fjs = d.getElementsByTagName(s)[0];
	if (d.getElementById(id)) {return;}
	js = d.createElement(s); js.id = id;
	js.src = "https://connect.facebook.net/en_US/sdk.js";
	fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
*/
//END Facebook default initialization

//jquery implementation:
$(document).ready(function() {
	$.ajaxSetup({ cache: true });
	$.getScript('https://connect.facebook.net/en_US/sdk.js', function(){
		FB.init({
			appId: '2721267708098832',
			version: 'v3.2' // or v2.1, v2.2, v2.3, ...
		});     
		$('#loginbutton,#feedbutton').removeAttr('disabled');
		FB.getLoginStatus(updateStatusCallback);
	});
	
	$("#share").click(function() {
		fbShare("https://google.com");
	});
	
	$("#shareandlike").click(function() {
		fbShareAndLike("https://zenoftechnology.com");
	});
});

function updateStatusCallback() {
	console.log("This function runs when the FB Login status is determined");
}
function fbShare(page) {
	FB.ui({
		method: 'share',
		href: page
	}, function(response){});
}

function fbShareAndLike(page) {
	FB.ui({
		method: 'share_open_graph',
		action_type: 'og.likes',
		action_properties: JSON.stringify({
			object:page,
		})
	}, function(response){
		// Debug response (optional)
		console.log(response);
	});
}

