//direct off of developer.twitter.com - how to include the twitter widget JS
window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));

//custom example code
$(document).ready(function() {
	$("#share_button").click(function() { 
		var share_url = $("#share_url").val();
		twttr.widgets.createShareButton(
			share_url, 
			document.getElementById("share_button_display"),
			{	
				screen_name: null, 
				hashtag: "#LearnToCode",
			});			
	});
	
	$("#display_tweet_button").click(function() {
		twttr.widgets.createTweet(
			'511181794914627584',
			document.getElementById('tweet_display'),
			//NOTE: twitter does not support jQuery selectors, so you have to use
			//the core JS implementation of get element by ID and not the jQuery
			//selector below
			//$("#tweet_display"), 
			{
				align: 'left'
			}).then(function (el) {
				console.log("Tweet displayed.")
			});
	});
	
	$("#display_timeline_button").click(function() {
		twttr.widgets.createTimeline({
			sourceType: 'profile',
			screenName: 'nickruffilo'
		},
		document.getElementById('timeline_display'),
		{
			width: '450',
			height: '700',
			related: 'programmermemes,iamdevloper'
		}).then(function (el) {
			console.log('Embedded a timeline.')
		});
	});
});