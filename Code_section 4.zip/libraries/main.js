//load everything in a document.ready so that we know everything is loaded.
$(document).ready(function() {
	
	//load i Have Cookies
	$('body').ihavecookies({
	  title: "Cookies & Privacy",
	  message: "This website uses cookies to ensure you get the best experience on our website."
	});
	
	//load the date time picker:
	$('#picker').dateTimePicker({
	  dateFormat: "YYYY-MM-DD HH:mm"
	});

	
});
