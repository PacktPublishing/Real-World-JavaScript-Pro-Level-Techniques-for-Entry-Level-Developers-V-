$(document).ready(function() {
	//give a hover event to the button to show
	$("#hover_modal").hover(function() {
		$("#myModal").modal({
			keyboard: false,
			show:true,
			backdrop: true
		});
	});
	
	//set an event when the modal closes so we can do something
	$("#myModal").on("hide.bs.modal", function(e) {
		//e is the event that caused the modal to close, we don't have to use it
		alert("The modal just closed...");
	});
	
	//initialize the tooltips 
	$('[data-toggle="tooltip"]').tooltip();
	
	//enable the popover: 
	$('#popover_text').popover({
		animation: true,
		content: 'This is expanded information that will stay untill it is dismissed.  It can also include <b>html tags</b>',
		html: true,
		placement: 'top',
		title: 'Popovers',
		trigger: 'hover'
		
	});
	
	//have the button display the alert
	$("#alert_button").click(function() {
		$("#alert").addClass("show");
	});
});