var map;
var google_api_key = "AIzaSyBDW4T-usvr99-_uELulYaDf4Cg6K1heu0"
var api_key = 'e6d6c49fa6fcd0fb7c646f9093f614e4';
var news_api_key = '84e3ba15174949dbb9fdb8f30660d9d6';
var active_marker = {};
var active_marker_pos = {};

//initialize twitter_account//direct off of developer.twitter.com - how to include the twitter widget JS
window.twttr = (function(d, s, id) {
	var js, fjs = d.getElementsByTagName(s)[0],
		t = window.twttr || {};
	if (d.getElementById(id)) return t;
	js = d.createElement(s);
	js.id = id;
	js.src = "https://platform.twitter.com/widgets.js";
	fjs.parentNode.insertBefore(js, fjs);

	t._e = [];
	t.ready = function(f) {
		t._e.push(f);
		//now that it's loaded, attempt to load the timeline if the cookie is setif (Cookies.get("twitter_account") !== "") {
	};

	return t;
}(document, "script", "twitter-wjs"));

//this event will run once, once the twttr object has been loaded
twttr.ready(function() {
	console.log("twitter ready");
	if (Cookies.get("twitter_account") !== "") {
		console.log("Loading twitter with "+ Cookies.get("twitter_account"));
		updateTwitterTimeline(Cookies.get("twitter_account"));
	}
});

//google maps documentation: https://developers.google.com/maps/documentation/javascript/earthquakes#circle_size
//this is a callback function driven by an event
function initMap() {
	map = new google.maps.Map(document.getElementById('map'), {
		center: {lat: 2.8, lng: -187},
		zoom: 1.5
	});
	
	map.addListener('rightclick', function(evt) {
		console.log(evt);
		//set the long and lat into a cookie for further reading
		Cookies.set("active_long",evt.latLng.lng(), {expires:30});
		Cookies.set("active_lat",evt.latLng.lat(), {expires:30});
		//update our active marker
		if (active_marker_pos !== {}) {
			//if the active marker has been set, lets remove the old marker
			active_marker.setMap(null);
		}
		
		active_marker_pos = {lat: parseFloat(Cookies.get("active_lat")), lng: parseFloat(Cookies.get("active_long"))};
		active_marker = new google.maps.Marker({position: active_marker_pos, map: map});

		getWeatherByLatLong(evt.latLng.lat(), evt.latLng.lng(),"imperial");	
	  });
	
	//moved here from (document).ready as google object wasn't ready by the 
	//time the doc was loaded
	if (Cookies.get("active_lat") !== "") {
		console.log("Attempting to add pin to " + Cookies.get("active_lat") + " " + Cookies.get("active_long"));
		//load the last local weather
		getWeatherByLatLong(Cookies.get("active_lat"), Cookies.get("active_long"),"imperial");	
		//create a pin on the map
		active_marker_pos = {lat: parseFloat(Cookies.get("active_lat")), lng: parseFloat(Cookies.get("active_long"))};
		console.log("Creating pin at:");
		console.log(active_marker_pos);
		active_marker = new google.maps.Marker({position: active_marker_pos, map: map});
	}
}

function getWeatherByLatLong(lat,lng, unit) {
	console.log("Getting weather for " + lat + " and " + lng);
	var unit_ext = (typeof(unit) != "undefined") ? "&units="+unit : "";
	var api_url = "http://api.openweathermap.org/data/2.5/weather?lat="+lat+"&lon="+lng+unit_ext + "&APPID="+api_key;
	switch (unit) {
		case "imperial":
			unit_display = "F";
			break;
		case "metric":
			unit_display = "C";
			break;
		defualt:
			unit_display = "K";
			break;
	}
	unit_display = "<span class='degree_display'>"+unit_display+"</span>";

	$.ajax({
		url: api_url
	}).done(function(resp) {
		console.log(resp);
		var sunrise = new Date(resp.sys.sunrise*1000);
		var sunset = new Date(resp.sys.sunset*1000);
		//display the current weather
		
		$("#weather_header").html(resp.name);
		$("#weather_temp").html(resp.main.temp + unit_display);
		$("#weather_description").html(resp.weather.description);
		$("#sunrise").html(sunrise.getHours() + ":" + sunrise.getMinutes())
		$("#sunset").html(sunset.getHours() + ":" + sunset.getMinutes())

		//determine what icon to display
		var icon = "";
		switch (resp.weather[0].main.toLowerCase()) {
			case "clear":
				icon = "fa-sun";
				break;
			case "clouds":
				icon = "fa-cloud";
				break;
			case "snow":
				icon = "fa-snowflake";
				break;
			case "rain":
				icon = "fa-cloud-rain";
				break;
		}
		console.log("Should be adding icon " + icon);
		$("#weather_icon").removeClass().addClass("fas").addClass(icon);
		
		//get the forecast and give a short summary
		getForecastByLocation(lat,lng,unit,"summary");

		
	});
}

function getForecastByLocation(lat,lng, unit, display) {
	var unit_ext = (typeof(unit) != "undefined") ? "&units="+unit : "";
	var api_url = "http://api.openweathermap.org/data/2.5/forecast?lat="+lat+"&lon="+lng+unit_ext + "&APPID="+api_key;
	var unit_display = "";
	switch (unit) {
		case "imperial":
			unit_display = "F";
			break;
		case "metric":
			unit_display = "C";
			break;
		defualt:
			unit_display = "K";
			break;
	}
	unit_display = "<span class='degree_display'>"+unit_display+"</span>";
	$.ajax({
		url: api_url
	}).done(function(resp) {
		console.log(resp);
		//display different data based on the source that is calling the function
		if (display === "summary") {
			//display the next 5 predictions, which come every 3 hrs
			var forecast_display = "";
			for (item in resp.list) {
				if (item >= 5) break;
				var forecast_date = new Date(resp.list[item].dt*1000);
				//need to determine which icon to display based off the weather
				var icon = "";
				switch (resp.list[item].weather[0].main.toLowerCase()) {
					case "clear":
						icon = "fa-sun";
						break;
					case "clouds":
						icon = "fa-cloud";
						break;
					case "snow":
						icon = "fa-snowflake";
						break;
					case "rain":
						icon = "fa-cloud-rain";
						break;
				}
				forecast_display += ""+
					"<div class='forecast_summary'>"+
					"<div class='fc_sm_hours'>"+forecast_date.getHours()+"h</div>"+
					"<div class='fc_icon'><i class='fas "+icon+"'></i></div>"+
					"<div class='fc_temp'>"+(resp.list[item].main.temp.toFixed(0))+unit_display+"</div>"+
					"</div>";
			}
			$("#weather_forecast").html(forecast_display);
		} else if (display === "detailed") {
			$("#detailed_forecast_city").html(resp.city.name);
	
			var labels = []; //this will be the Time/days with icon
			var data = []; //this will be the temperature
			
			for (item in resp.list) {
				var date = new Date(resp.list[item].dt*1000);
				var icon = "";
				switch (resp.list[item].weather[0].main.toLowerCase()) {
					case "clear":
						icon = "fa-sun";
						break;
					case "clouds":
						icon = "fa-cloud";
						break;
					case "snow":
						icon = "fa-snowflake";
						break;
					case "rain":
						icon = "fa-cloud-rain";
						break;
				}
				console.log(date);
				labels.push(ordinal_suffix_of(date.getDate()) + " " +
						""+date.getHours()+"h");
				/*
				labels.push(date.getMonth() + "/" + date.getYear() + "<br/>" +
						""+date.getHour+"h"+
						"<i class='vas "+icon+"'></i>");
						*/
				data.push(resp.list[item].main.temp);				
			}			
			var ctx = document.getElementById("detailed_forecast").getContext('2d');
			var myChart = new Chart(ctx, {
				type: 'line',
				data: {
					labels: labels,
					datasets: [{
						label: 'Temperature',
						data: data
					}]
				}
			});
		}
	});
}

//document ready is an event that triggers when the document has been loaded
$(document).ready(function() {
	$("#get_weather_button").click(function() {
		getCurrentWeatherByZip($("#postal_code").val(),$("#weather_units").val());
	});
	
	$("#get_forecast_button").click(function() {
		getForecastByZip($("#postal_code").val(),$("#weather_units").val());
	});
	
	//set up the detailed forecast button and data mapping
	$("#weather_forecast_detail").click(function() {
		console.log("running click...");
		if (Cookies.get("current_lat") === "") {
			//if the current lat/long isn't set, display a message
			$("#detailed_forecast_message").html("<p>If you want to see detailed weather, please select a location.</p>");
			$("#detailed_forecast_message").show();
		} else {
			$("#detailed_forecast_message").hide();
			console.log("about to set forecast by location");
			getForecastByLocation(Cookies.get("active_lat"),Cookies.get("active_long"), "imperial", "detailed");			
		}
	});
	$('[data-toggle="tooltip"]').tooltip();
	
	$("#update_twitter_handle_confirm").click(function() {
		$("#twitter_modal").modal("hide");
		Cookies.set("twitter_account",$("#twitter_handle").val());
		updateTwitterTimeline(Cookies.get("twitter_account"));		
	});
	
	loadLatestNews();
	
});

function updateTwitterTimeline(username) {
	twttr.widgets.createTimeline({
		sourceType: 'profile',
		screenName: username
	},
	document.getElementById('twitter_feed'),
	{
		width: '100%',
		height: '600',
		related: 'programmermemes,iamdevloper'
	}).then(function (el) {
		console.log('Embedded a timeline.')
	});
}

function loadLatestNews() {
	console.log("loading latest news");
	var url = 'https://newsapi.org/v2/top-headlines?' +
          'country=us&' +
          'apiKey=' + news_api_key;
	$.ajax({
		url: url
	}).done(function(resp) {
		console.log("News API results: ");
		console.log(resp);
		var indicators = "";
		var content = "";
		for (item in resp.articles) {
			if (item >= 10) break; //only load 10 items...
			indicators += "<li data-target='#news_headlines' data-slide-to='"+item+"'></li>\n";
			content += "		<div class='carousel-item'>"+
				"<h4><a href='" + resp.articles[item].url + "' target='_blank'>"
				+ resp.articles[item].title + "</a></h4>";
			if (resp.articles[item].urlToImage !== null) {
				content += "<img src='" + resp.articles[item].urlToImage + "' class='news_image'/>"; 
			}
			if (resp.articles[item].description !== null) {
				content += "<p class='news_description'>"+ resp.articles[item].description+"</p>";
			}
			content += "</div>";

		}
		/*
		<li data-target="#news_headlines" data-slide-to="0" class="active"></li>
		<div class="carousel-item active">
			<img class="d-block w-100" src="..." alt="First slide">
		</div>
		*/
		$("#news_indicators").html(indicators);
		$("#news_inner").html(content);
		$('#news_inner .carousel-item').first().addClass('active');
		$('#news_indicators > li').first().addClass('active');

		
		$('#news_headlines').carousel({ride:true});
	});


}

//borrowed from https://stackoverflow.com/questions/13627308/add-st-nd-rd-and-th-ordinal-suffix-to-a-number
function ordinal_suffix_of(i) {
    var j = i % 10,
        k = i % 100;
    if (j == 1 && k != 11) {
        return i + "st";
    }
    if (j == 2 && k != 12) {
        return i + "nd";
    }
    if (j == 3 && k != 13) {
        return i + "rd";
    }
    return i + "th";
}
